//: [< Back | ](Scene7) [Start >](Scene1)
import SwiftUI
import PlaygroundSupport
import AVFoundation


struct EndCreditsScene: View {
    
    // configure audio player
    @State private var audioPlayer: AVAudioPlayer? = {
        
        var player: AVAudioPlayer
        
        if let audioURL = Bundle.main.url(forResource: "end-credits-sound", withExtension: "m4a") {
            
            try! player = AVAudioPlayer(contentsOf: audioURL)
            player.volume = 5
            player.numberOfLoops = -1
            
            return player
                    
        } else {
            print("No audio file found")
        }
        
        return nil
    }()
    
    var body: some View {
        
        Image(uiImage: UIImage(named: "the-end")!)
            
        .onAppear {
            audioPlayer?.play()
        }
    }
}

PlaygroundPage.current.setLiveView(EndCreditsScene())
