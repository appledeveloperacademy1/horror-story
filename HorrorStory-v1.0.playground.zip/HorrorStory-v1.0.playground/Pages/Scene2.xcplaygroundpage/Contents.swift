//: [< Back | ](Scene1) [Next >](Scene3)
import SwiftUI
import PlaygroundSupport
import AVFoundation


struct SceneTwo: View {
    
    // configure audio player
    @State private var audioPlayer: AVAudioPlayer? = {
        
        var player: AVAudioPlayer
        
        if let audioURL = Bundle.main.url(forResource: "happy-music", withExtension: "m4a") {
            
            try! player = AVAudioPlayer(contentsOf: audioURL)
            player.volume = 5
            player.numberOfLoops = -1
            
            return player
                    
        } else {
            print("No audio file found")
        }
        
        return nil
    }()
    
    var body: some View {
        
        VStack {
            Image(uiImage: UIImage(named: "scene-1-background.png")!)
            Image(uiImage: UIImage(named: "scene-1-textFrame.png")!)
        }
        
        .onAppear {
            audioPlayer?.play()
        }
    }
}

PlaygroundPage.current.setLiveView(SceneTwo())
