//: [< Back | ](Scene5) [Next >](Scene7)
import SwiftUI
import PlaygroundSupport
import AVFoundation


struct SceneSix: View {
    
    @State var audioPlayer: AVAudioPlayer?
    var surpriseSound = "scene-5-surpriseSound"
    var screamSound = "scene-5-screamSound"
    
    var body: some View {
        
        VStack {
            Image(uiImage: UIImage(named: "scene-5-background.png")!)
            
            Image(uiImage: UIImage(named: "scene-5-textFrame.png")!)
        }
        
        .onAppear {
            playAudio(musicFile: surpriseSound)
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                playAudio(musicFile: screamSound)
            }
        }
    }
    
    
    func playAudio(musicFile: String) {
        audioPlayer = nil
    
        if let audioURL = Bundle.main.url(forResource: musicFile, withExtension: "m4a") {
            
            do {
                try audioPlayer = AVAudioPlayer(contentsOf: audioURL)
                audioPlayer?.volume = 5
                audioPlayer?.play()
                print("play music file: \(musicFile)")
                
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }
            
        } else {
            print("No audio file found")
        }
    }
}

PlaygroundPage.current.setLiveView(SceneSix())
