//: [< Back | ](Scene6) [Next >](Scene8)
import SwiftUI
import PlaygroundSupport
import AVFoundation


struct SceneSeven: View {
    
    @State private var angle: Double = 0
    
    // configure audio player
    @State private var audioPlayer: AVAudioPlayer? = {
        
        var player: AVAudioPlayer
        
        if let audioURL = Bundle.main.url(forResource: "scene-6-laugh", withExtension: "mp3") {
            
            do {
                try player = AVAudioPlayer(contentsOf: audioURL)
                player.volume = 5
                player.numberOfLoops = -1
                
                return player
                    
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }

        } else {
            print("No audio file found")
        }
        
        return nil
    }()
    
    var body: some View {
       
        ZStack {
            
            VStack {
                
                //backgound images
                Image(uiImage: UIImage(named: "scene-6-background.png")!)
                
                Image(uiImage: UIImage(named: "scene-6-textFrame.png")!)
            }
            
            // mary
            Image(uiImage: UIImage(named: "mary-knife-image")!)
                .position(x: 125, y: 150)
                .rotationEffect(.degrees(angle))
        }
        
        .onAppear {
            audioPlayer?.play()
            withAnimation(.linear(duration: 0.4).repeatForever(autoreverses: true)) {
                angle -= 25
            }
        }
    }
}


PlaygroundPage.current.setLiveView(SceneSeven())
