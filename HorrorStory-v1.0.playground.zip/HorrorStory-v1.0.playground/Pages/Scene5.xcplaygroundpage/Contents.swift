//: [< Back | ](Scene4) [Next >](Scene6)
import SwiftUI
import PlaygroundSupport
import AVFoundation


struct SceneFive: View {
    
    @State var audioPlayer: AVAudioPlayer?
    
    var body: some View {
        
        VStack {
            Image(uiImage: UIImage(named: "scene-4-background.png")!)
            
            Image(uiImage: UIImage(named: "scene-4-textFrame.png")!)
        }
        .onAppear {
            playAudio()
        }
    }
    
    
    func playAudio() {
        
        let musicFile = "scene-4-scream-sound"
        if let audioURL = Bundle.main.url(forResource: musicFile, withExtension: "m4a") {
            
            do {
                try audioPlayer = AVAudioPlayer(contentsOf: audioURL)
                audioPlayer?.volume = 3
//                audioPlayer?.numberOfLoops = -1
                audioPlayer?.play()
                print("play music file: \(musicFile)")
                
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }
            
        } else {
            print("No audio file found")
        }
    }
}

PlaygroundPage.current.setLiveView(SceneFive())
