//:[Next >](Scene2)
import SwiftUI
import PlaygroundSupport
import AVFoundation


struct TitleScene: View {
    
    // title images
    private let happyImage = "happy-title.png"
    private let horrorImage = "horror-title.png"
    
    // title music
    private let happyMusic = "happy-music"
    private let horrorMusic = "horror-music"
    
    // state variables
    @State private var isShowingHorrorTitle = false {
        didSet {
            print("isShowingHorrorTitle state: \(isShowingHorrorTitle)")
        }
    }
    
    // audio player
    @State var audioPlayer: AVAudioPlayer?
    
    var body: some View {
        let imageName = isShowingHorrorTitle ? horrorImage : happyImage
        
        ZStack {
            Image(uiImage: UIImage(named: imageName)!)
                .scaledToFit()
                .frame(width: 400, height: 320)
        }
        
        .onAppear {
            playAudio()
            toggleTitleImage()
        }
    }
    
    
    func toggleTitleImage() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 8) {
            isShowingHorrorTitle.toggle()
            playAudio()
        }
    }
    
    
    func playAudio() {
        audioPlayer = nil
        
        let musicFile = isShowingHorrorTitle ? horrorMusic : happyMusic
        if let audioURL = Bundle.main.url(forResource: musicFile, withExtension: "m4a") {
            
            do {
                try audioPlayer = AVAudioPlayer(contentsOf: audioURL)
                audioPlayer?.volume = isShowingHorrorTitle ? 10 : 1
                audioPlayer?.numberOfLoops = -1
                audioPlayer?.play()
                print("play music file: \(musicFile)")
                
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }
            
        } else {
            print("No audio file found")
        }
    }
}

PlaygroundPage.current.setLiveView(TitleScene())
