//: [< Back | ](Scene3) [Next >](Scene5)
import SwiftUI
import PlaygroundSupport
import AVFoundation


struct SceneFour: View {
    
    // configure audio player
    @State private var audioPlayer: AVAudioPlayer?
    
    var body: some View {
        
        VStack {
            Image(uiImage: UIImage(named: "scene-3-background.png")!)
            
            Image(uiImage: UIImage(named: "scene-3-textFrame.png")!)
        }
        
        .onAppear {
            playAudio(musicFile: "male-huh-sound", format: "mp3")
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.25) {
                playAudio(musicFile: "scene-3-music", format: "mp3")
            }
        }
    }
    
    func playAudio(musicFile: String, format: String) {
        audioPlayer = nil
    
        if let audioURL = Bundle.main.url(forResource: musicFile, withExtension: format) {
       
            try! audioPlayer = AVAudioPlayer(contentsOf: audioURL)
            audioPlayer?.volume = 5
            audioPlayer?.play()
            print("play music file: \(musicFile)")
                
        } else {
            print("No audio file found")
        }
    }
}

PlaygroundPage.current.setLiveView(SceneFour())
